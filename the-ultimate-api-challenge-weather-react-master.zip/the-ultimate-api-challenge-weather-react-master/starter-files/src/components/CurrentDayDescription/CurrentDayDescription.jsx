import React from 'react';

const CurrentDayDescription = () => (
    <div className="mt-4 mt-md-2">
        <div className="d-flex flex-column mb-2"></div>
    </div>
);

export default CurrentDayDescription;
