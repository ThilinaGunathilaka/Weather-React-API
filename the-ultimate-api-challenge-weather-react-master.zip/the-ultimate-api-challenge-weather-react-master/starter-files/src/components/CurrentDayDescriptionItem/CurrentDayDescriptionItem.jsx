import React from 'react';

const CurrentDayDescriptionItem = () => (
    <div className="d-flex justify-content-between">
        <p className="mb-0 font-weight-bolder text-uppercase"></p>
        <p className="mb-0"></p>
    </div>
);

export default CurrentDayDescriptionItem;
