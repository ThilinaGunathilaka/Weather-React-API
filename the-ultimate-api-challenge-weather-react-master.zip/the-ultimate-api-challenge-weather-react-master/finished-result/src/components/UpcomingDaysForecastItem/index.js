export { default } from './UpcomingDaysForecastItem';
