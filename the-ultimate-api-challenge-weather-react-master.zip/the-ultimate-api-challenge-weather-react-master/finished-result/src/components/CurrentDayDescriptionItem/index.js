export { default } from './CurrentDayDescriptionItem';
