export { default } from './UpcomingDaysForecast';
